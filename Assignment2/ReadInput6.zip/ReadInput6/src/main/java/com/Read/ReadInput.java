/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.Read;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author jaspr
 */
public class ReadInput extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        //SECTION 1
        String academicterm = request.getParameter("academicterm");
        String academicyear = request.getParameter("academicyear");
        String empstatus[] = request.getParameterValues("empsts");
        String OtherEmpSts = request.getParameter("Otherempsts");
        //SECTION 2
        String studentname = request.getParameter("studentname");
        String relation = request.getParameter("relation");
        String studnuid = request.getParameter("studnuid");
        String empname = request.getParameter("empname");
        String empnuid = request.getParameter("empnuid");
        String department = request.getParameter("department");
        String campusloc = request.getParameter("campusloc");
        String phone = request.getParameter("phone");
        String supervisor = request.getParameter("supervisor");

        //SECTION 4
        String empsig = request.getParameter("empsig");
        String sec4date = request.getParameter("sec4date");

        //SECTION 4
        String hrmapproval = request.getParameter("hrmapproval");
        String sec5date = request.getParameter("sec5date");

        //SECTION 3
        String check3[] = request.getParameterValues("check3");
        String course1 = request.getParameter("course1");
        String coursename1 = request.getParameter("coursename1");
        String supersig1 = request.getParameter("supersig1");
        String credithrs1 = request.getParameter("credithrs1");
        String day1 = request.getParameter("day1");
        String time1 = request.getParameter("time1");

        String course2 = request.getParameter("course2");
        String coursename2 = request.getParameter("coursename2");
        String supersig2 = request.getParameter("supersig2");
        String credithrs2 = request.getParameter("credithrs2");
        String day2 = request.getParameter("day2");
        String time2 = request.getParameter("time2");

        String course3 = request.getParameter("course3");
        String coursename3 = request.getParameter("coursename3");
        String supersig3 = request.getParameter("supersig3");
        String credithrs3 = request.getParameter("credithrs3");
        String day3 = request.getParameter("day3");
        String time3 = request.getParameter("time3");

        out.println("<h3>" + "SECTION 1" + "</h3>");
        out.println("<TABLE BORDER=1px>\n"
                + "<TR>"
                + "<TH>Heading"
                + "</TH>"
                + "<TH>Value"
                + "</TH>"
        );
        out.println("<TR><TD>ACADEMIC TERM</TD>"
                + "<TD>" + academicyear + "</TD></TR>"
                + "<TR><TD>ACADEMIC YEAR</TD>"
                + "<TD>" + academicyear + "</TD></TR>"
        );

        out.println("<TR><TD>EMPLOYEE STATUS</TD>");
        if (empstatus.length == 1) {
            out.println("<TD>" + empstatus[0] + "</TD></TR>");
        } else if (empstatus.length == 2) {
            out.println("<TD>" + empstatus[0] + "," + empstatus[1] + "</TD></TR>");
        } else if (empstatus.length == 3) {
            out.println("<TD>" + empstatus[0] + "," + empstatus[1] + "," + empstatus[2] + "</TD></TR>");
        }
        out.println("<TR><TD>Other EmpSts</TD>"
                + "<TD>" + OtherEmpSts + "</TD></TR>");
        out.println("</TABLE>");
        
        out.println("<h3>" + "SECTION 2" + "</h3>");
        
        out.println("<TABLE BORDER=1px>\n");
        out.println("<TR>"
                + "<TH>Student Name</TH>"
                + "<TH>Relation to Employee</TH>"
                + "<TH>Student NUID</TH>" 
                + "<TH>Employee Name</TH>"
                + "<TH>Employee NUID</TH>"
                + "<TH>Department</TH>"
                + "<TH>Campus Location</TH>"
                + "<TH>Phone</TH>"
                + "<TH>Supervisor</TH>"
                + "</TH></TR>"
        );

        out.println("<TR>");
        out.println("<TD>" + studentname + "</TD>");
        out.println("<TD>"+ relation + "</TD>");
        out.println("<TD>"+ studnuid + "</TD>");
        out.println("<TD>"+ empname + "</TD>");
        out.println("<TD>"+ empnuid + "</TD>");
        out.println("<TD>"+ department + "</TD>");
        out.println("<TD>"+ campusloc + "</TD>");
        out.println("<TD>"+ phone + "</TD>");
        out.println("<TD>"+ supervisor + "</TD>");
        out.println("</TR>");
        out.println("</TABLE>");
        
        out.println("<h4>Applicabe School/Program</h4>");
        for(String s:check3){
            out.println("<li>" + s + "</li>");
        }
        
        out.println("<h3>" + "SECTION 3" + "</h3>");
        out.println("<TABLE BORDER=1px>\n"
                + "<TR>"
                + "<TH>Course Number"
                + "</TH>"
                + "<TH>Course Name"
                + "</TH>"
                + "<TH>Supervisor Signature"
                + "</TH>"
                + "<TH>Credit Hrs."
                + "</TH>"
                + "<TH>Day(s)"
                + "</TH>"
                + "<TH>Time"
                + "</TH>"
        );
        
        out.println("<TR>");
        out.println("<TD>" + course1 + "</TD>");
        out.println("<TD>" + coursename1 + "</TD>");
        out.println("<TD>"+ supersig1 + "</TD>");
        out.println("<TD>"+ credithrs1 + "</TD>");
        out.println("<TD>"+ day1 + "</TD>");
        out.println("<TD>"+ time1 + "</TD>");
        out.println("</TR>");

        out.println("<TR>");
        out.println("<TD>" + course2 + "</TD>");
        out.println("<TD>" + coursename2 + "</TD>");
        out.println("<TD>"+ supersig2 + "</TD>");
        out.println("<TD>"+ credithrs2 + "</TD>");
        out.println("<TD>"+ day2 + "</TD>");
        out.println("<TD>"+ time2 + "</TD>");
        out.println("</TR>");
        
        out.println("<TR>");
        out.println("<TD>" + course3 + "</TD>");
        out.println("<TD>" + coursename3 + "</TD>");
        out.println("<TD>"+ supersig3 + "</TD>");
        out.println("<TD>"+ credithrs3 + "</TD>");
        out.println("<TD>"+ day3 + "</TD>");
        out.println("<TD>"+ time3 + "</TD>");
        out.println("</TR>");
        out.println("</TABLE>");
        
        out.println("<h3>" + "SECTION 4" + "</h3>");
        out.println("<TABLE BORDER=1px>\n"
                + "<TR>"
                + "<TH>Employee Signature"
                + "</TH>"
                + "<TH>Date");
       
        
        out.println("<TR>");
        out.println("<TD>" + empsig + "</TD>");
        out.println("<TD>" + sec4date + "</TD>");
        out.println("</TR>");
        out.println("</TABLE>");
        
        out.println("<h3>" + "SECTION 5" + "</h3>");
        out.println("<TABLE BORDER=1px>\n"
                + "<TR>"
                + "<TH>HRM Approval"
                + "</TH>"
                + "<TH>Date");
        
        out.println("<TR>");
        out.println("<TD>" + hrmapproval + "</TD>");
        out.println("<TD>" + sec5date + "</TD>");
        out.println("</TR>");
        out.println("</TABLE>");
        
        
        
        
        

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
