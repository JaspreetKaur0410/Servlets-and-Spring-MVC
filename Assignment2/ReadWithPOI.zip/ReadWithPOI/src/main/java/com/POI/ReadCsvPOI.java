/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.POI;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

/**
 *
 * @author jaspr
 */
@WebServlet(name = "ReadCsvPOI", urlPatterns = {"/readcsv/store.xls"})
public class ReadCsvPOI extends HttpServlet {

    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter pw = response.getWriter();
        
        pw.println("<a href=\"../logout.jsp\">Click here to log out</a>");
        pw.println("<br/>");
        try {

            FileInputStream file = new FileInputStream(new File("F:\\D Drive\\MS_COURSE_21\\#second_semester\\WebTools\\Assignments\\Assignment2\\store.xls"));

            //Get the workbook instance for XLS file 
            HSSFWorkbook workbook = new HSSFWorkbook(file);

            //Get first sheet from the workbook
            HSSFSheet sheet = workbook.getSheetAt(0);

            //Iterate through each rows from first sheet
            
            pw.println("<TABLE BORDER=1px>\n"
                    + "<TR>");
           
            Iterator< Row> rowIterator = sheet.iterator();
            Row row1 = rowIterator.next();
            Iterator< Cell> cellIterator1 = row1.cellIterator();
            while (cellIterator1.hasNext()) {
                Cell cell = cellIterator1.next();
                pw.println("<TH>" + cell.getStringCellValue());
            }
            pw.println("</TH>");
            pw.println("</TR>");
       
            while (rowIterator.hasNext()) {
                Row row = rowIterator.next();

                //For each row, iterate through each columns
                pw.println("<TR>\n");
                Iterator< Cell> cellIterator = row.cellIterator();
                while (cellIterator.hasNext()) {
                    
                    Cell cell = cellIterator.next();
                    
                    switch (cell.getCellType()) {
                        case BOOLEAN:
                            
                            pw.println("<TD>" + cell.getBooleanCellValue() + "\t\t");
                            pw.println("</TD>\n");
                            break;
                        case NUMERIC:
                            pw.println("<TD>" + cell.getNumericCellValue() + "\t\t");
                            pw.println("</TD>\n");
                            break;
                        case STRING:
                            pw.println("<TD>" + cell.getStringCellValue() + "\t\t");
                            pw.println("</TD>\n");
                            break;
                    }
                }
               pw.println("</TR>\n");
            }
        
            file.close();
            FileOutputStream out
                    = new FileOutputStream(new File("F:\\D Drive\\MS_COURSE_21\\#second_semester\\WebTools\\Assignments\\Assignment2\\store.xls"));
            workbook.write(out);
            out.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

   
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

   
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
