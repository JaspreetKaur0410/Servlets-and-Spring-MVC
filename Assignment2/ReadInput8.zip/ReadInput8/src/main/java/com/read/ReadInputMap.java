/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.read;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author jaspr
 */
@WebServlet(name = "ReadInputMap", urlPatterns = {"/ReadInputMap"})
public class ReadInputMap extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        Map params = request.getParameterMap();
        Set params_set = params.entrySet();
        Iterator it = params_set.iterator();
        out.println("<a href=\"logout.jsp\">Click here to log out</a>");
        out.println("<br/>");
        out.println("<TABLE BORDER=1px>\n" + "<TR>");
        while (it.hasNext()) {
            Map.Entry<String, String[]> entry = (Map.Entry<String, String[]>) it.next();
            String key = entry.getKey();
            out.println("<TH>" + key + "</Th>");
        }
        out.println("</TR>");

        Map params1 = request.getParameterMap();
        Set params_set1 = params.entrySet();
        Iterator it1 = params_set1.iterator();
        out.println("<TR>");
        while (it1.hasNext()) {
            Map.Entry<String, String[]> entry = (Map.Entry<String, String[]>) it1.next();
            String[] value = entry.getValue();
            String key = entry.getKey();
            if (key.equals("check3")) {
                String check[] = request.getParameterValues("check3");
                if (check.length == 1) {
                    out.println("<TD>" + check[0] + "</TD>");
                } else if (check.length == 2) {
                    out.println("<TD>" + check[0] + "," + check[1] + "</TD>");
                } else if (check.length == 3) {
                    out.println("<TD>" + check[0] + "," + check[1] + "," + check[2] + "</TD>");
                }
                else if (check.length == 4) {
                    out.println("<TD>" + check[0] + "," + check[1] + "," + check[2] + ","+ check[3] + "</TD>");
                }
                 else if (check.length == 5) {
                    out.println("<TD>" + check[0] + "," + check[1] + "," + check[2] + "," + check[3] + "," + check[4] + "</TD>");
                }
                else if (check.length == 6) {
                    out.println("<TD>" + check[0] + "," + check[1] + "," + check[2] + "," + check[3] + "," + check[4]+ "," + check[5] + "</TD>");
                }
              
            }
            else if (key.equals("empsts")) {
                String empstatus[] = request.getParameterValues("empsts");
                if (empstatus.length == 1) {
                    out.println("<TD>" + empstatus[0] + "</TD>");
                } else if (empstatus.length == 2) {
                    out.println("<TD>" + empstatus[0] + "," + empstatus[1] + "</TD>");
                } else if (empstatus.length == 3) {
                    out.println("<TD>" + empstatus[0] + "," + empstatus[1] + "," + empstatus[2] + "</TD>");
                }
            }
            else{
                for (int i = 0; i < value.length; i++) {
                    out.println("<TD>" + value[i].toString() + "</TD>");
                }

            } /*else {
                out.println("<TD>" + value[0].toString() + "</TD>");
            }*/
        }
        out.println("</TR>");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
