/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.read;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author jaspr
 */
@WebServlet(name = "ReadInput", urlPatterns = {"/ReadInput"})
public class ReadInput extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        Enumeration en = request.getParameterNames();
        out.println("<a href=\"logout.jsp\">Click here to log out</a>");
        out.println("<br/>");
        out.println("<TABLE BORDER=1px>\n" + "<TR>");

        while (en.hasMoreElements()) {
            Object obj = en.nextElement();
            String s = (String) obj;
            out.println("<TH>" + s + "</Th>");
        }
        out.println("</TR>");

        Enumeration en1 = request.getParameterNames();
        out.println("<TR>");
        while (en1.hasMoreElements()) {
            Object obj = en1.nextElement();
            String s = (String) obj;
            if (s.equals("check3")) {
                String check[] = request.getParameterValues("check3");
                if (check.length == 1) {
                    out.println("<TD>" + check[0] + "</TD>");
                } else if (check.length == 2) {
                    out.println("<TD>" + check[0] + "," + check[1] + "</TD>");
                } else if (check.length == 3) {
                    out.println("<TD>" + check[0] + "," + check[1] + "," + check[2] + "</TD>");
                }
                else if (check.length == 4) {
                    out.println("<TD>" + check[0] + "," + check[1] + "," + check[2] + ","+ check[3] + "</TD>");
                }
                 else if (check.length == 5) {
                    out.println("<TD>" + check[0] + "," + check[1] + "," + check[2] + "," + check[3] + "," + check[4] + "</TD>");
                }
                else if (check.length == 6) {
                    out.println("<TD>" + check[0] + "," + check[1] + "," + check[2] + "," + check[3] + "," + check[4]+ "," + check[5] + "</TD>");
                }
              
            }
            else if (s.equals("empsts")) {
                String empstatus[] = request.getParameterValues("empsts");
                if (empstatus.length == 1) {
                    out.println("<TD>" + empstatus[0] + "</TD>");
                } else if (empstatus.length == 2) {
                    out.println("<TD>" + empstatus[0] + "," + empstatus[1] + "</TD>");
                } else if (empstatus.length == 3) {
                    out.println("<TD>" + empstatus[0] + "," + empstatus[1] + "," + empstatus[2] + "</TD>");
                }
            }
            else{
            String value = request.getParameter(s);
            out.println("<TD>" + value + "</TD>");
            }
        }
        out.println("</TR>");
        out.println("</TABLE>");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
