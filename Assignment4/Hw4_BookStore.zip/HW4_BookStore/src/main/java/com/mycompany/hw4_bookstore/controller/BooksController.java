/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.hw4_bookstore.controller;

import com.mycompany.hw4_bookstore.Dao.BooksDao;
import com.mycompany.hw4_bookstore.bean.BooksBean;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

/**
 *
 * @author jaspr_000
 */
public class BooksController extends AbstractController {

    BooksDao dao;

    public BooksController() {
        dao = new BooksDao();
    }

    protected ModelAndView handleRequestInternal(
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {

        String action = request.getParameter("action");
        PrintWriter out = response.getWriter();

        ModelAndView mv = null;
        if (action == null) {
            mv = new ModelAndView("bookscount");
        } else {
            if (action.equals("add")) {
                request.setAttribute("countbooks", Integer.parseInt(request.getParameter("countbooks")));
                mv = new ModelAndView("addbooks");
            }
            if (action.equals("addbook")) {
                int count = Integer.parseInt(request.getParameter("countbooks"));

                String[] isbns = request.getParameterValues("isbn");
                String[] titles = request.getParameterValues("title");
                String[] authors = request.getParameterValues("author");
                String[] prices = request.getParameterValues("price");

                for (int i = 0; i < count; i++) {
                    BooksBean book = new BooksBean(isbns[i], titles[i], authors[i], Double.parseDouble(prices[i]));
                    dao.insertBook(book);
                    List<BooksBean> listBooks = dao.selectAllBooks();
                    request.setAttribute("listBooks", listBooks);
                }
                mv = new ModelAndView("list");
            }
            if (action.equals("list")) {
                List<BooksBean> listBooks = dao.selectAllBooks();
                request.setAttribute("listBooks", listBooks);
                mv = new ModelAndView("list");
            }
        }

        return mv;
    }

}
