/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.hw4_part7.controller;

import com.mycompany.hw4_part7.service.UtilityClass;
import java.io.PrintWriter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

/**
 *
 * @author jaspr_000
 */

public class StrController extends AbstractController{
    ApplicationContext context;
    public StrController() {
       context = new ClassPathXmlApplicationContext("applicationContext.xml");      
    }
   

    @Override
    protected ModelAndView handleRequestInternal(HttpServletRequest hsr, HttpServletResponse hsr1) throws Exception {
       
        Object ob = context.getBean("service");
        UtilityClass uc = (UtilityClass)ob;
        hsr.setAttribute("uc", uc.getStringParam());
        hsr.setAttribute("ob", uc);
        return new ModelAndView("getstr");

    }
}
