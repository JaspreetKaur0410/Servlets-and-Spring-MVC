/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.hw4_shopingcart.controller;

import com.mycompany.hw4_shopingcart.bean.Product;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

/**
 *
 * @author jaspr_000
 */
@Controller
public class CartController {

    HttpSession session;
    ArrayList<Product> items;

    public CartController() {
        items = new ArrayList();
    }

    @PostMapping("/login.htm")
    protected ModelAndView handleRequestInternalPost(
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {
        return new ModelAndView("login");
    }

    @GetMapping("/login.htm")
    protected ModelAndView handleRequestInternalGet(
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {
        return new ModelAndView("login");
    }

    @PostMapping("/index.htm")
    protected ModelAndView handleRequestInternalPostIndex(
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {
        String username = request.getParameter("l_email");
        String password = request.getParameter("l_password");
        session = request.getSession(false);

        if (session == null) {
            return new ModelAndView("login");
        } else {
            if (username.equals("jaspreetkaur22mar@gmail.com") && password.equals("jaspr")) {
                session = request.getSession(false);
                if (session != null) {
                    session.setAttribute("username", username);
                    session.setAttribute("password", password);
                    return new ModelAndView("index");
                }
            } else if (username == null || password == null) {
                return new ModelAndView("login");
            } else {
                return new ModelAndView("login");
            }
        }
        return new ModelAndView("index");
    }

    @GetMapping("/index.htm")
    protected ModelAndView handleRequestInternalGetIndex(
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {

        String username = request.getParameter("l_email");
        String password = request.getParameter("l_password");
        
        session = request.getSession(false);
       
        if (session == null) {
            return new ModelAndView("login");
        } else if(session != null){
            //if (username.equals("jaspreetkaur22mar@gmail.com") && password.equals("jaspr")) {
                session = request.getSession(false);
                if (session != null) {
                    session.setAttribute("username", username);
                    session.setAttribute("password", password);
                    return new ModelAndView("index");
                }
                else {
                return new ModelAndView("login");
            }
                
            } 
        return new ModelAndView("index");
    }

    @GetMapping("/books.htm")
    protected ModelAndView handleRequestInternalGetBooks(
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {

        String link = request.getParameter("action");
        if (link.equals("books")) {
            return new ModelAndView("books");
        } else if (link.equals("phones")) {
            return new ModelAndView("phones");
        } else if (link.equals("women")) {
            return new ModelAndView("women");
        }
        return null;
    }

    @GetMapping("/addtocart.htm")
    protected ModelAndView handleRequestInternalGetAddToCart(
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {

        session = request.getSession(false);
        String user = (String) session.getAttribute("username");
        String[] books = request.getParameterValues("book");
        String[] phones = request.getParameterValues("phone");
        String[] womens = request.getParameterValues("women");

        if (user != null) {

            String link = request.getParameter("link");
            request.setAttribute("link", link);

            if (books != null) {
                for (int i = 0; i < books.length; i++) {
                    Product product = new Product(books[i]);
                    items.add(product);
                }
            }
            if (phones != null) {
                for (int i = 0; i < phones.length; i++) {
                    Product product = new Product(phones[i]);
                    items.add(product);
                }
            }
            if (womens != null) {
                for (int i = 0; i < womens.length; i++) {
                    Product product = new Product(womens[i]);
                    items.add(product);
                }
            }
            session.setAttribute("bookslist", books);
            session.setAttribute("phonelist", phones);
            session.setAttribute("womenlist", womens);
            session.setAttribute("itemlist", items);
            return new ModelAndView("addtocart");
        }

        return null;
    }

    @PostMapping("/addtocart.htm")
    protected ModelAndView handleRequestInternalGetAddToCartPost(
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {

        HttpSession session = request.getSession(false);
        String user = (String) session.getAttribute("username");
        String[] books = request.getParameterValues("book");
        String[] phones = request.getParameterValues("phone");
        String[] womens = request.getParameterValues("women");

        if (user != null) {

            String link = request.getParameter("link");
            request.setAttribute("link", link);

            if (books != null) {
                for (int i = 0; i < books.length; i++) {
                    Product product = new Product(books[i]);
                    items.add(product);
                }
            }
            if (phones != null) {
                for (int i = 0; i < phones.length; i++) {
                    Product product = new Product(phones[i]);
                    items.add(product);
                }
            }
            if (womens != null) {
                for (int i = 0; i < womens.length; i++) {
                    Product product = new Product(womens[i]);
                    items.add(product);
                }
            }
            session.setAttribute("bookslist", books);
            session.setAttribute("phonelist", phones);
            session.setAttribute("womenlist", womens);
            session.setAttribute("itemlist", items);
            return new ModelAndView("addtocart");
        }

        return null;
    }

    @GetMapping("remove")
    protected ModelAndView handleRequestInternalGetRemoveGet(
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {
        HttpSession session = request.getSession(false);
        String user = (String) session.getAttribute("username");

        if (user != null) {
            session.removeAttribute(request.getParameter("item"));
            items.remove(request.getParameter("item"));

            if (items != null) {
                for (int i = 0; i < items.size(); i++) {

                    if ((items.get(i).toString()).equals(request.getParameter("item"))) {
                        items.remove(i);
                    }
                }

                session.setAttribute("items", items);
                return new ModelAndView("list");
            }
        }
        return null;
    }

    @GetMapping("list")
    protected ModelAndView handleRequestInternalListGet(
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {
        PrintWriter out = response.getWriter();
        session = request.getSession(false);
        out.println("<h1>" + session.getId() + "</h1>");
        request.setAttribute("items", session.getAttribute("itemlist"));
        return new ModelAndView("list");

    }

    @GetMapping("logout")
    protected ModelAndView handleRequestInternalLogoutGet(
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {

        return new ModelAndView("logout");

    }

}
