/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.hw4_movies.controller;

import com.mycompany.hw4_movies.dao.DAO;
import com.mycompany.hw4_movies.pojo.Movies;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

/**
 *
 * @author jaspr_000
 */
public class MoviesController extends AbstractController {

    DAO dao;

    public MoviesController() {
        dao = new DAO();
    }

    protected ModelAndView handleRequestInternal(
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {

        PrintWriter out = response.getWriter();

        String action = request.getParameter("action");

        ModelAndView mv = null;

        if (action == null) {
            List<Movies> listmovies = dao.selectAllMovies();
            request.setAttribute("listmovies", listmovies);
            mv = new ModelAndView("listmovies");
        } else {

            if (action.equals("new")) {
                out.println("<h1>" + "Hello1" + "</h1>");
                mv = new ModelAndView("movieform");
            } else if (action.equals("insert")) {
                out.println("<h1>" + "Hello54" + "</h1>");
                String movieid = request.getParameter("movieid");
                String year = request.getParameter("year");
                String title = request.getParameter("title");
                String actress = request.getParameter("actress");
                String actor = request.getParameter("actor");
                String genre = request.getParameter("genre");
                out.println("<h1>" + movieid + "</h1>");
                Movies movie = new Movies(Integer.parseInt(movieid), title, actress, actor, genre, Integer.parseInt(year));
                dao.insertMovie(movie);

                List<Movies> listmovies = dao.selectAllMovies();
                request.setAttribute("listmovies", listmovies);
                mv = new ModelAndView("listmovies");
            } else if (action.equals("search")) {
                mv = new ModelAndView("search");
            } else if (action.equals("searching")) {
                String search = request.getParameter("searchbyid");

                if (request.getParameter("s_movie").equals("Search By ID")) {
                    List<Movies> searchedmovies = dao.search_by_id(Integer.parseInt(search));
                    request.setAttribute("searchedmovies", searchedmovies);
                    mv = new ModelAndView("viewsearchedmovie");
                } else if (request.getParameter("s_movie").equals("Search By Title")) {
                    List<Movies> searchedmovies = dao.search_by_title(search);
                    request.setAttribute("searchedmovies", searchedmovies);
                    mv = new ModelAndView("viewsearchedmovie");
                } else if (request.getParameter("s_movie").equals("Search By Actress")) {
                    List<Movies> searchedmovies = dao.search_by_actress(search);
                    request.setAttribute("searchedmovies", searchedmovies);
                    mv = new ModelAndView("viewsearchedmovie");
                } else {
                    out.println("<h1>" + "ERROR IN SEARCHING" + "</h1>");
                    mv = new ModelAndView("search");
                }
            } else if (action.equals("list")) {
                List<Movies> listmovies = dao.selectAllMovies();
                request.setAttribute("listmovies", listmovies);
                mv = new ModelAndView("listmovies");
            } else if (action.equals("update")) {
                String id = request.getParameter("movieid");
                List<Movies> searchedmovies = dao.search_by_id(Integer.parseInt(id));
                request.setAttribute("searchedmovies", searchedmovies.get(0));
                mv = new ModelAndView("update");
            } else if (action.equals("saveupdates")) {
                String movieid = request.getParameter("movieid");
                String year = request.getParameter("year");
                String title = request.getParameter("title");
                String actress = request.getParameter("actress");
                String actor = request.getParameter("actor");
                String genre = request.getParameter("genre");
                Movies movie = new Movies(Integer.parseInt(movieid), title, actress, actor, genre, Integer.parseInt(year));
                dao.updateMovie(movie);
                response.sendRedirect("movies.htm");
            } else if (action.equals("delete")) {
                String id = request.getParameter("movieid");
                dao.deleteMovie(Integer.parseInt(id));
                response.sendRedirect("movies.htm");
            } else {
                out.println("<h1>" + "Hello2" + "</h1>");
                List<Movies> listmovies = dao.selectAllMovies();
                mv = new ModelAndView("update");
            }
        }
        out.println("<h1>" + "Hello3" + "</h1>");
        return mv;

    }

    private ModelAndView movieform(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        PrintWriter out = response.getWriter();
        out.println("Hello");
        ModelAndView v1 = new ModelAndView("movieform");
        return v1;
    }

    private ModelAndView insertMovie(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        PrintWriter out = response.getWriter();
        //out.println("Hello2");
        String movieid = request.getParameter("movieid");
        String year = request.getParameter("year");
        String title = request.getParameter("title");
        String actress = request.getParameter("actress");
        String actor = request.getParameter("actor");
        String genre = request.getParameter("genre");
        out.println("<h1>" + movieid + "</h1>");
        Movies movie = new Movies(Integer.parseInt(movieid), title, actress, actor, genre, Integer.parseInt(year));
        dao.insertMovie(movie);

        List<Movies> listmovies = dao.selectAllMovies();
        request.setAttribute("listmovies", listmovies);
        ModelAndView v1 = new ModelAndView("movieform");
        return v1;
    }

    private ModelAndView listMovies(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        List<Movies> listmovies = dao.selectAllMovies();
        request.setAttribute("listmovies", listmovies);
        ModelAndView v1 = new ModelAndView("listmovies");
        return v1;
    }

    private ModelAndView searchmovie(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        ModelAndView v1 = new ModelAndView("search");
        return v1;
    }

    private ModelAndView searchingmovie(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        String search = request.getParameter("searchbyid");

        if (request.getParameter("s_movie").equals("Search By ID")) {
            List<Movies> searchedmovies = dao.search_by_id(Integer.parseInt(search));
            request.setAttribute("searchedmovies", searchedmovies);
            ModelAndView v1 = new ModelAndView("viewsearchedmovie");
            return v1;
        } else if (request.getParameter("s_movie").equals("Search By Title")) {
            List<Movies> searchedmovies = dao.search_by_title(search);
            request.setAttribute("searchedmovies", searchedmovies);
            ModelAndView v1 = new ModelAndView("viewsearchedmovie");
            return v1;
        } else if (request.getParameter("s_movie").equals("Search By Actress")) {
            List<Movies> searchedmovies = dao.search_by_actress(search);
            request.setAttribute("searchedmovies", searchedmovies);
            ModelAndView v1 = new ModelAndView("viewsearchedmovie");
            return v1;
        } else {
            PrintWriter out = response.getWriter();
            out.println("<h1>" + "ERROR IN SEARCHING" + "</h1>");
            ModelAndView v1 = new ModelAndView("viewsearchedmovie");
            return v1;
        }

    }

    private ModelAndView updateMovie(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        String id = request.getParameter("movieid");
        List<Movies> searchedmovies = dao.search_by_id(Integer.parseInt(id));
        request.setAttribute("searchedmovies", searchedmovies.get(0));
        ModelAndView v1 = new ModelAndView("update");
        return v1;
    }

    private ModelAndView saveUpdates(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {

        String movieid = request.getParameter("movieid");
        String year = request.getParameter("year");
        String title = request.getParameter("title");
        String actress = request.getParameter("actress");
        String actor = request.getParameter("actor");
        String genre = request.getParameter("genre");
        Movies movie = new Movies(Integer.parseInt(movieid), title, actress, actor, genre, Integer.parseInt(year));
        dao.updateMovie(movie);
        ModelAndView v1 = new ModelAndView("list");
        return v1;
    }

    private ModelAndView deleteUser(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        String id = request.getParameter("movieid");
        dao.deleteMovie(Integer.parseInt(id));
        ModelAndView v1 = new ModelAndView("list");
        return v1;

    }

}
